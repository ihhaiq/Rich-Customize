Rich-Customize i18n runtime key fix

Copy lib/i18n-keys.js and the complete lib/lang/ folder over your current project.
Then run:
npx tgcloud push
npx tgcloud webhook sync
npx tgcloud run handlers/message "{ chat: { id: YOUR_ID, type: 'private' }, from: { id: YOUR_ID, first_name: 'Test', language_code: 'ar' }, text: '/start' }"
