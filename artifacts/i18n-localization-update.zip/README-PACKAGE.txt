Rich-Customize — per-language i18n update

Copy every file/folder from this archive into the project root and replace existing files.
Preserve the lib/lang/ directory structure.
Then delete every path listed in DELETE_THESE.txt.

After copying, test with:
npx tgcloud run message "{}"
